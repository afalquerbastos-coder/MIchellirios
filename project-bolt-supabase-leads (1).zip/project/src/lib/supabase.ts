import { createClient } from '@supabase/supabase-js';

// Configuração direta (seguro para frontend, pois é a anon key)
const supabaseUrl = 'https://vjxxgusmemzuiknklzsr.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZqeHhndXNtZW16dWlrbmtsenNyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTk1MjY1MzQsImV4cCI6MjA3NTEwMjUzNH0.UoLr4oZQcAwSrQmNakMIdrGnKAlxOvSN5rMCovuWlzk';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export interface Lead {
  id?: string;
  name: string;
  email: string;
  phone: string;
  created_at?: string;
}

export async function saveLead(lead: Lead) {
  const { data, error } = await supabase
    .from('leads')
    .insert([
      {
        nome: lead.name,
        email: lead.email,
        telefone: lead.phone,
      },
    ])
    .select()
    .maybeSingle();

  if (error) throw error;
  return data;
}
